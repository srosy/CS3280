﻿namespace SimpleLibrarySystem
{
    public enum BookLocation
    {
        FIRST_FLOOR,
        SECOND_FLOOR,
        THIRD_FLOOR
    }
}
