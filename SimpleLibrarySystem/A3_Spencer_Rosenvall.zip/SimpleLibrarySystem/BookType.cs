﻿namespace SimpleLibrarySystem
{
    public enum BookType
    {
        SCIENCE,
        ART,
        MATH,
        HISTORY,
        EDUCATION,
        FICTION
    }
}
