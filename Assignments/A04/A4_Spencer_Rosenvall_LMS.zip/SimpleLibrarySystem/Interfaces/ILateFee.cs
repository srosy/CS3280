﻿namespace SimpleLibrarySystem.Interfaces
{
    public interface ILateFee
    {
        decimal ChargeFee();
    }
}
