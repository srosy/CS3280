﻿namespace SimpleLibrarySystem
{
    public enum Genre
    {
        SCIENCE,
        ART,
        MATH,
        HISTORY,
        EDUCATION,
        FICTION
    }
}
