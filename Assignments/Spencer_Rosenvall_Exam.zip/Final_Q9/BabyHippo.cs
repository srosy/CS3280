﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Q9
{
    public class BabyHippo : Hippo
    {
        public bool IsBaby { get; set; }
        public override string NickName { get; set; }
    }
}
