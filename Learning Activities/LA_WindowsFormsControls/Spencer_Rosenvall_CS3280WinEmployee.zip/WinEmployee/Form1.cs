﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinEmployee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cmbState_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show($"{cmbState.SelectedItem.ToString()} ({cmbState.SelectedIndex.ToString()})");
        }

        private void cbIsMarried_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show($"cbIsMarried is checked: {cbIsMarried.Checked}");
        }

        private void rbSalaried_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show($"Salaried: {rbSalaried.Checked}\nCommission: {rbCommission.Checked}\nBase+Commission: {rbBaseCommission.Checked}");
            lblSalary.Visible = true;
            tbSalary.Visible = true;
            lblSales.Visible = false;
            tbSales.Visible = false;
            lblCommissionRate.Visible = false;
            tbCommissionRate.Visible = false;
        }

        private void rbCommission_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show($"Salaried: {rbSalaried.Checked}\nCommission: {rbCommission.Checked}\nBase+Commission: {rbBaseCommission.Checked}");
            lblSalary.Visible = false;
            tbSalary.Visible = false;
            lblSales.Visible = true;
            tbSales.Visible = true;
            lblCommissionRate.Visible = true;
            tbCommissionRate.Visible = true;
        }

        private void rbBaseCommission_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show($"Salaried: {rbSalaried.Checked}\nCommission: {rbCommission.Checked}\nBase+Commission: {rbBaseCommission.Checked}");
            lblSalary.Visible = true;
            tbSalary.Visible = true;
            lblSales.Visible = true;
            tbSales.Visible = true;
            lblCommissionRate.Visible = true;
            tbCommissionRate.Visible = true;   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var employeeInfo = $"{tbFirstName.Text} {tbLastName.Text}\r\n" +
                $"{tbAddr1.Text} {tbAddr2.Text}, {cmbState.SelectedItem}\r\n" +
                $"{tbSSN.Text}\r\n";
            
            if (tbSalary.Visible)
            {
                employeeInfo += $"Salary: {tbSalary.Text}\r\n";
            }
            if (tbCommissionRate.Visible)
            {
                employeeInfo += $"Commission Rate: {tbCommissionRate.Text}\r\n";
            }
            if (tbSales.Visible)
            {
                employeeInfo += $"Sales: {tbSales.Text}\r\n";
            }


            tbEmployeeInfo.Text = employeeInfo;
        }
    }
}
