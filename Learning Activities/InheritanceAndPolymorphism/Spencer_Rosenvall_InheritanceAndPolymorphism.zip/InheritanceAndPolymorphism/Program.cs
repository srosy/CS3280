﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceAndPolymorphism
{
    public class Program
    {
        static void Main(string[] args)
        {
            CommissionEmployee commissionEmployee = new CommissionEmployee("Spencer", "Rosenvall", "111-55-9999", 10000m, 0.50m);
            BasePlusCommissionEmployee basePlusCommissionEmployee
                = new BasePlusCommissionEmployee("Gavin", "Rosenvall", "222-54-8975", 15245m, 0.25m, 800m);
            BasePlusCommissionEmployee basePlusCommissionEmployee2
                = new BasePlusCommissionEmployee("Scooby", "Doo", "222-25-8975", 75m, 0.50m, 650m);

            //// Commission Employee Info
            //Console.WriteLine("Commission Employee Info: ");
            //Console.WriteLine("Gross Sales: " + commissionEmployee.GrossSales);
            ////Console.WriteLine("SSN: " + commissionEmployee.SSN);
            //Console.WriteLine("Earning: " + commissionEmployee.Earning());

            //// Base + Commission Employee Info
            //Console.WriteLine("\nBase + Commission Employee Info: ");
            //Console.WriteLine("Gross Sales: " + basePlusCommissionEmployee.GrossSales);
            ////Console.WriteLine("SSN: " + basePlusCommissionEmployee.SSN);
            //Console.WriteLine("Earning: " + basePlusCommissionEmployee.Earning());

            //commissionEmployee.PrintInfo();
            //basePlusCommissionEmployee.PrintInfo();


            Console.WriteLine("\n******* polymorphism starts *******");
            // base class reference points to the child class object
            // CommissionEmployee (base class) reference points to the BasePlusCommissionEmployee (child class)
            CommissionEmployee commissionEmployee1 = new BasePlusCommissionEmployee("Gavin", "Rosenvall", "222-54-8975", 15245m, 0.25m, 800m);
            // perform operations via inheritance

            // calls base class method and not child class method if virtual override is not used
            Console.WriteLine("Earning: " + commissionEmployee1.Earning());


            Console.WriteLine("\n****** base class reference = child class reference ******");
            commissionEmployee = basePlusCommissionEmployee;
            Console.WriteLine("Earning: " + commissionEmployee.Earning());

            Console.WriteLine("\n****** build an array of employees and print earnings ******");
            CommissionEmployee[] commissionEmployeesArray = new CommissionEmployee[3];
            commissionEmployeesArray[0] = commissionEmployee;
            commissionEmployeesArray[1] = basePlusCommissionEmployee;
            commissionEmployeesArray[2] = basePlusCommissionEmployee2;

            for (int i = 0; i < commissionEmployeesArray.Length; i++)
                Console.WriteLine($"*** {commissionEmployeesArray[i].Earning()} ***");

            Console.ReadLine();
        }
    }
}
