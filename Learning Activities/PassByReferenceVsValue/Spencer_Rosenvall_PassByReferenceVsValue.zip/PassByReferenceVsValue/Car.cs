﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassByReferenceVsValue
{
    public class Car
    {
        public string _make;
        public string _model;
        public int _yearBuilt;
        public decimal _price;
    }
}
