﻿namespace SimpleLibrarySystem
{
    public enum ItemLocation
    {
        FIRST_FLOOR,
        SECOND_FLOOR,
        THIRD_FLOOR
    }
}
